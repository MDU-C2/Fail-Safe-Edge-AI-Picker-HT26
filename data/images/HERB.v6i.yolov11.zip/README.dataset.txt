# HERB > 2026-09-29 10:48am
https://universe.roboflow.com/ranimeree-xpzt7/herb-dhp9g

Provided by a Roboflow user
License: CC BY 4.0

